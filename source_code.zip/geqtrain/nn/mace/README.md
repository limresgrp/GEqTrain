GEqTrain uses modules and code of the [`MACE`](https://github.com/ACEsuit/mace) [1] model.
We use, however, only a limited subset of that library.

To simplify installation, we include and adapt here a small subset of `MACE` that is neccessary for our code.

  [1]  Batatia, Ilyes and Kovacs, David P and Simm, Gregor and Ortner, Christoph and Csanyi, Gabor. MACE: Higher Order Equivariant Message Passing Neural Networks for Fast and Accurate Force Fields. In Advances in Neural Information Processing Systems (2022, Vol. 35, pp. 11423-11436).